var product=[{
    img:[
        { id: "", img: "name" },
        { id: "", img: "name" },
        { id: "", img: "name" },
        { id: "", img: "name" },
        { id: "", img: "name" },
        { id: "", img: "name" },
        { id: "", img: "name" },
    ],
        
    video: [{ id: "", img: "name" }],
    olmos:'',
    title:"blak uzuk",
    price:122,
    BandWidth:'Delicate',
    Metal:"",
    category:"",
    subcategory:"",
    minicategory:""
}
]